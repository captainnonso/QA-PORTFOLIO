import { Given, When, Then } from '@badeball/cypress-cucumber-preprocessor';
import paymentgateWay from '../../pageObjectElement/paymentgateway';

const pay = new paymentgateWay

When ('I Click Payment Link to create link',()=>{
    pay.createPaymentLink()
  
})


When ('I Click Paymentpage to create it',()=>{
   
    pay.createPaymentPage()
})



When ('I Click Product page to create it',()=>{
   
    pay.createProductPage()
})

When ('I Create recurring page', () => {

    pay.createRecurringPAGE()
})

When ('I Create Split payment', () => {

    pay.SplitpaymentCreation()
})

When ('I Create Sub account', () => {

    pay.SubAccountCreation()
})

When('Create Qr Code', () =>{

    gateway.qrcodecreation()
    
    });
    
    When('Create Multiple Qr Code', () =>{
    
    gateway.multipledynamicqrcode()
    
    });
    
    When('Create subscription plan', () =>{
    
    gateway.plancreation()
    
    });
    
    When('Create subscription', () =>{
    
    gateway.subscriptioncreation()
    
    });
    
    
    When('Create Invoicing', () =>{
    
    gateway.invoicingcreation()
    
    });
    
    When('Create Reward', () =>{
    
    gateway.rewardcreation()
    
    });


