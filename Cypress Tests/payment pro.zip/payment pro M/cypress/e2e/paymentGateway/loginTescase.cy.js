import login from '../../pageObjectElement/login';
import { Given, When, Then } from '@badeball/cypress-cucumber-preprocessor';

const logintest = new login

Given("I AM ON THE LANDING PAGE", () => {
    cy.visit('/');
});

When("I ENETER A VALID LOGIN DETAILS", () => {
    logintest.logincredentials()
});
       