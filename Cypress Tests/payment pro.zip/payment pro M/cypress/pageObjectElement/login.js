class login{

emailField = "#email";
passwordField = "#password"
loginBtn = "button[type='submit']"
email = "endurance+1000@blusalt.net"
password = "Ekundayo9189@"




logincredentials(){

    cy.wait(3000)
    cy.get(this.emailField).type(this.email)
    cy.get(this.passwordField).type(this.password)
    cy.get(this.loginBtn).click()
    cy.wait(4000)
    
}


}
export default login