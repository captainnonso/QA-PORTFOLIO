class paymentgateWay{

    paymentlink = "//span[normalize-space()='Payment Links']"
    createLinkbtn = "//span[normalize-space()='Create Payment Link']" // xpert
    linkNameBtn = "#name"
    descriptionBtn = "#description"
    amountBtn = "#amount"
    usuageMultiple = "#multiple"
    expire = "#expire"
    createBtn = "button[type='submit']"
    titleName = "Testing on going"
    description = "link is working e lo fokan bale"
    amount = "1000"
    successfullMessage = "//p[normalize-space()='Payment Link Created Successfully']"

    // payment page element
    paymentPageBtn = "//span[normalize-space()='Payment Pages']" // xpart
    createPaymentPageBTN = "div[id='payment-pages-header'] button[type='button'] span"
    basicPageBTN = "//span[normalize-space()='Create a simple one time payment page.']" // expart
    pageTitleBtn = "#name"
    pageDescriptionBTN = "#description"
    currencyfield = "#currency"
    naira = "//div[contains(text(),'NGN')]"
    previewPage ="//button[normalize-space()='Preview']" // expert
    closebtn = "//button[normalize-space()='Close']" // expert
    nextBtn = "//button[normalize-space()='Next']" //expert
    
    // product page element
     
    productBTN = "//span[contains(text(),'Collect payments for a product or service you are ')]" // expert
    pageTitleBtn = "input[placeholder='Payment Page Title']"
    selectProductBTN = "#products"
    product = "div[data-value='cooked']"

    // recurring page element
    Recurringbtn = "//p[normalize-space()='Recurring payment Page']"
    plandropdown = "#plan"
    

    //Split payment page
    Splitpaymenttab = "//span[normalize-space()='Split Payments']" //xpath
    Splitpaymentcreation = "//span[normalize-space()='Create Split Group']" //xpath
    Subaccountdropdown = "//span[normalize-space()='Choose Sub Account to add']" //xpath
    Splitentervalue = "button[name='sub_accounts'] span"
    Splitvaue = "50"
    closeVA = "body > div:nth-child(4) > div:nth-child(2) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > form:nth-child(1) > div:nth-child(4) > div:nth-child(2) > div:nth-child(1) > button:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(2) > svg:nth-child(1) > path:nth-child(1)"

    //subaccount 
    Subaccounttab = "//span[normalize-space()='Sub Accounts']" //xpath
    SubaccountCreation = "//span[normalize-space()='Add SubAccount']" //xpath
    bankname = "button[name='bank_name'] span"
    inputacctnumber = "//input[@placeholder='Enter the account number']"
    Accountnumber = "8063567555"
    subaccname ="//input[@placeholder='Give this Sub Account a name e.g. Savings Account']"
    palmpay = "palmpay"

    //Dynamic QR Code
    QRCodetab = "//span[normalize-space()='QR Codes']" //xpath
    QRCodecreation = "//span[normalize-space()='Create QR Code']" //xpath
    DynamicQRCode = "//body/div[@role='dialog']/div[@dir='ltr']/div/div/div[1]"

            //QRCODES
            Qrcodetab = "//span[normalize-space()='QR Codes']"  //xpath
            QrcodeCreation = "//span[normalize-space()='Create QR Code']" //xpath
            DynamicQrcodeCreation = "//p[normalize-space()='Dynamic']" //xpath
            SuccessfulCreation = "p[class='mb-2 text-[18px] font-semibold']"
        
            //multipledynmic
            multipledynamicQrcodeCreation = "//p[normalize-space()='Dynamic Multiple']" //xpath
            Choosesubacctinfo = "#sub_accounts"
        
        
        //Plan
            Subscriptiontab = "//span[normalize-space()='Subscriptions']" //xpath
            Subscriptioncreation = "//span[normalize-space()='Create Subscription']" //xpath
            plandropdown ="#plan"
            coupondropdown = "#coupon"
            walletdropdown = "button[id='wallet'] span[class='truncate font-light text-gray-two']"
            PlanCreation = "//span[normalize-space()='Create Plan']" //xpath
            plantab = "//span[@class='min-w-16 text-center'][normalize-space()='Plans']" //xpath
            Subtypedropdown = "#subscription_type"
            Intervaldropdown = "#interval"
            monthlyoptiondropdown = "div[id='radix-:r1d8:']" 
            onetimesubtype = "div[id='radix-:r1d1:']"
        
        //invoicing 
        invoicingtab = "//span[normalize-space()='Invoicing']" //xpath
        Invoicingcreation = "//span[normalize-space()='Create Invoice']" //xpath
        customerdropdown = "#customer"
        issuedatedate = "input[placeholder='Pick Issue Date']"
        endingdate = "input[placeholder='Pick Expiry Date']"
        itemname = "button[id='line_items.[0]']"
        itemquatintty = "input[id='line_items[0].quantity']"
        quantity  = "50"
        Createinvoicebtn = "//span[@class='hidden lg:block'][normalize-space()='Create Invoice']"
        
        //RewardCheckout
        rewardcheckout = "//span[normalize-space()='Checkout Rewards']" //xpath
        rewardtab = "//span[@class='min-w-16 text-center'][normalize-space()='Rewards']" //xpath
        rewardcreation = "//span[normalize-space()='Create Reward']" //xpath
        rewardcatergory = "#categoryRef"
        rewardpoints = "#rewardPoints"
        startdate = "#startDate"
        enddate = "#endDate"
        userlimit = "#userLimit"
        
        
        


    

    createPaymentLink(){
        
        cy.xpath(this.paymentlink).click()
        cy.xpath(this.createLinkbtn).click()
        cy.get(this.linkNameBtn).type(this.titleName)
        cy.get(this.descriptionBtn).type(this.description)
        cy.get(this.amountBtn).type(this.amount)
        cy.get(this.usuageMultiple).click()
        cy.get(this.expire).click()
        cy.get(this.createBtn).click()
        cy.contains('Payment Link Created Successfully').should('be.visible');
        cy.xpath(this.successfullMessage) 
        .should('contain', 'Payment Link Created Successfully')
        .and('be.visible');
        cy.wait(4000); 
        
    }


  



    createPaymentPage(){
        
        cy.xpath(this.paymentPageBtn).click()
        cy.get(this.createPaymentPageBTN).click()
        cy.xpath(this.basicPageBTN).click()
        cy.wait(2000)
        cy.get(this.pageTitleBtn).type(this.titleName)
        cy.get(this.pageDescriptionBTN).type(this.description)
        cy.get(this.usuageMultiple).click()
        cy.get(this.currencyfield).click()
        cy.xpath(this.naira).click()
        cy.get(this.amountBtn).type(this.amount)

        cy.wait(4000); 
        cy.xpath(this.nextBtn).click()
        cy.get(this.expire).click()
        cy.get(this.createBtn).click()
        cy.contains('Payment Page Created Successfully').should('be.visible')
        cy.wait(4000);
 
    }



    createProductPage(){


      
        cy.xpath(this.paymentPageBtn).click()
        cy.get(this.createPaymentPageBTN).click()
    
        cy.xpath(this.productBTN).click()
        cy.get(this.pageTitleBtn).type(this.titleName)
        cy.get(this.pageDescriptionBTN).type(this.description)
    
        cy.get(this.usuageMultiple).click()
        cy.get(this.currencyfield).click()
        cy.xpath(this.naira).click()
        cy.get(this.selectProductBTN).click()
    
    
    
    
        cy.get('[role="group"]').should('be.visible').each(() => {
            cy.get('[role="option"]').then($options => {
              const randomIndex = Math.floor(Math.random() * $options.length);
              cy.wrap($options[randomIndex]).click();
            });
          });
          
    
    
        cy.get('[role="dialog"] + div') // assuming overlay is next to modal
        .click({ force: true });
      
    
        cy.xpath(this.nextBtn).click()
        cy.get(this.expire).click()
        cy.get(this.createBtn).click()
        cy.contains('Payment Page Created Successfully').should('be.visible')
        cy.wait(4000); 
        
        }



        createRecurringPAGE(){
        cy.xpath(this.paymentPageBtn).click()
        cy.get(this.createPaymentPageBTN).click()
        cy.xpath(this.Recurringbtn).click()
        cy.get(this.pageTitleBtn).type(this.titleName)
        cy.get(this.pageDescriptionBTN).type(this.description)
        cy.get(this.usuageMultiple).click()
        cy.get(this.currencyfield).click()
        cy.xpath(this.naira).click()
        cy.get(this.plandropdown).click()

        cy.get('[role="group"]').should('be.visible').each(() => {
            cy.get('[role="option"]').then($options => {
              const randomIndex = Math.floor(Math.random() * $options.length);
              cy.wrap($options[randomIndex]).click();
            });
          });
          
    
    
        cy.get('[role="dialog"] + div') // assuming overlay is next to modal
        .click({ force: true });
      
    
        cy.xpath(this.nextBtn).click()
        cy.get(this.expire).click()
        cy.get(this.createBtn).click()
        cy.contains('Payment Page Created Successfully').should('be.visible')
        cy.wait(4000); 


        }

        SplitpaymentCreation(){
        cy.xpath(this.Splitpaymenttab).click()
        cy.xpath(this.Splitpaymentcreation).click()
        cy.get(this.linkNameBtn).type(this.titleName)
        cy.xpath(this.Subaccountdropdown).click()

        cy.wait(2000)
      

        cy.get('[role="group"]').should('be.visible').each(() => {
            cy.get('[role="option"]').then($options => {
              const randomIndex = Math.floor(Math.random() * $options.length);
              cy.wrap($options[0]).click();
              // Find the option you want to deselect and click it again
        
             
            });
          });
          
       
          
    
    
        cy.get('[role="dialog"] + div') // assuming overlay is next to modal
        .click({ force: true });

        cy.wait(4000)

    
        cy.get('path[d="M18 6 6 18"]') // assuming overlay is next to modal
        .click({ force: true });



        cy.get('path[d="M18 6 6 18"]').eq(0).click(); 
         cy.get('[role="dialog"] + div') // assuming overlay is next to modal
        .click({ force: true });

        //cy.get(this.closeVA).click()

      
        cy.get(this.Splitentervalue).type(this.Splitvaue)
       
    
        cy.xpath(this.nextBtn).click()
    
        cy.contains('Payment Page Created Successfully').should('be.visible')
        cy.wait(4000); 

        cy.get(this.Splitvaue).type(this.Splitvaue)


        }

        SubAccountCreation(){
            cy.xpath(this.Splitpaymenttab).click()
            cy.xpath(this.Subaccounttab).click()
            cy.xpath(this.SubaccountCreation).click()
            cy.get(this.bankname).type(this.palmpay)

            cy.get('[role="dialog"] + div') // assuming overlay is next to modal
            .click({ force: true });


        cy.get('[role="group"]').should('be.visible').each(() => {
            cy.get('[role="option"]').then($options => {
              const randomIndex = Math.floor(Math.random() * $options.length);
              cy.wrap($options[randomIndex]).click();
            });
          });
          
    
    
        cy.get('[role="dialog"] + div') // assuming overlay is next to modal
        .click({ force: true });

        cy.get(this.inputacctnumber).type(this.Accountnumber)
        cy.get(this.subaccname).type("random")
        cy.get(this.createLinkbtn).click()



        }

        DynamicQRcode(){
            cy.xpath(this.QRCodetab).click()
            

        }



qrcodecreation() {
        cy.xpath(this.Qrcodetab).click()
        cy.xpath(this.QrcodeCreation).click()
        cy.xpath(this.DynamicQrcodeCreation).click()
        cy.get(this.namefield).type(this.name)
        cy.get(this.descriptionfield).type(this.description)
        cy.get(this.amountfield).type(this.amount)
        cy.get(this.expirydatebox).click()
        cy.get(this.submitbtn).click()
        cy.get(this.SuccessfulCreation).should('be.visible')

    }

    multipledynamicqrcode() {
        cy.xpath(this.Qrcodetab).click()
        cy.xpath(this.QrcodeCreation).click()
        cy.xpath(this.multipledynamicQrcodeCreation).click()
        cy.get(this.namefield).type(this.name)
        cy.get(this.descriptionfield).type(this.description)
        cy.get(this.Choosesubacctinfo).click()

        
    


    cy.get(this.expirydatebox).click()
    cy.get(this.submitbtn).click()

    }


    plancreation() {
        cy.xpath(this.Subscriptiontab).click()
        cy.xpath(this.plantab).click()
        cy.xpath(this.PlanCreation).click()
        cy.get(this.namefield).type(this.name)
        cy.get(this.descriptionfield).type(this.description)
        cy.get(this.amountfield).type(this.amount)
        cy.get(this.Subtypedropdown).click()
        cy.get(this.onetimesubtype).click()
        cy.get(this.Intervaldropdown).click()
        cy.get(this.monthlyoptiondropdown).click()
        cy.get(this.submitbtn).click()
        cy.get(this.SuccessfulCreation).should('be.visible')


    }

    subscriptioncreation(){
        cy.xpath(this.Subscriptiontab).click()
        cy.xpath(this.subscriptioncreation).click()
        cy.get(this.plandropdown).click()
        cy.get(this.coupondropdown).click()
        cy.get(this.walletdropdown).click()
        cy.get(this.submitbtn).click()
        cy.get(this.SuccessfulCreation).should('be.visible')

    }
    
    invoicingcreation(){
        cy.xpath(this.invoicingtab).click()
        cy.xpath(this.Invoicingcreation).click()
        cy.get(this.coupondropdown).click()
        cy.get(this.issuedatedate).click()
        cy.get(this.endingdate).click()
        cy.get(this.descriptionfield).description()
        cy.get(this.itemname).click()
        cy.get(this.itemquatintty).click()
        cy.get(this.Createinvoicebtn).click()
        cy.get(this.SuccessfulCreation).should('be.visible')

        
    }

    rewardcreation() {
        cy.xpath(this.rewardcheckout).click()
        cy.xpath(this.rewardtab).click()
        cy.xpath(this.rewardcreation).click()
        cy.get(this.namefield).type(this.name)
        cy.get(this.rewardcatergory).click()
        cy.get(this.startdate).click()
        cy.get(this.enddate).click()
        cy.get(this.rewardpoints).type("30")
        cy.get(this.userlimit).type("3")
        cy.get(this.SuccessfulCreation).should('be.visible')

    }

}
export default paymentgateWay